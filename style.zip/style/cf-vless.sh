#!/bin/bash
# //            🇵🇸 FREE PALESTINE 🇵🇸
# //                  🇮🇱 IS 🐷
# // ——————————————————————————————
# // Config SSH Account by XDXL STORE 🇮🇩
# // My Telegram: t.me/xdxl_store
# // My Channel: t.me/xdx_vpn
# // Telegram Group: t.me/GrupConfigId
# // Config User VLESS Account
# // ——————————————————————————————
Green="\e[92;1m"
RED="\033[31m"
PUB=$(cat /etc/slowdns/server.pub)
NS=$(cat /etc/xray/dns)
domain=$(cat /etc/xray/domain)
IP=$(curl -sS ipv4.icanhazip.com)
CITY=$(cat /etc/xray/city)
NC='\033[0m'
y="\033[1;93m"
g="\033[1;92m"
ungu='\033[0;35m'
function loadingsc() {
echo -e ""
echo -ne "Please wait... "
load
}
function garis() {
echo -e "${y} ────────────────────────────────────────────${NC}"
}
function Credit_Sc() {
sleep 1
echo -e ""
garis 
echo -e "${ungu}      Terimakasih sudah menggunakan-"
echo -e "        Script premium by Xdxl vpn"
garis
echo -e ""
exit 0
}
clear
NUMBER_OF_CLIENTS=$(grep -c -E "###" "/etc/vless/.vless.db")
if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
echo -e "${y}───────────────────────────${NC}"
echo -e "\e[1;97;101m   CONFIG VLESS ACCOUNT   ${NC}"
echo -e "${y}───────────────────────────${NC}"
echo ""
echo "You have no existing clients!"
clear
exit 1
fi

echo -e "${y}───────────────────────────${NC}"
echo -e "\e[1;97;101m   CONFIG VLESS ACCOUNT   ${NC}"
echo -e "${y}───────────────────────────${NC}"
echo "     No User  Expired"
grep -E "### " "/etc/vless/.vless.db" | cut -d ' ' -f 2-3 | nl -s ') '
until [[ ${Nomor} -ge 1 && ${Nomor} -le ${NUMBER_OF_CLIENTS} ]]; do
if [[ ${Nomor} == '1' ]]; then
read -rp "Select one client [1]: " Nomor
else
read -rp "Select one client [1-${NUMBER_OF_CLIENTS}]: " Nomor
fi
done

user=$(grep -E "###" "/etc/vless/.vless.db" | cut -d ' ' -f 2 | sed -n "${Nomor}"p)
uuid=$(grep -E "###" "/etc/vless/.vless.db" | cut -d ' ' -f 4 | sed -n "${Nomor}"p)
iplimit=$(grep -E "###" "/etc/vless/.vless.db" | cut -d ' ' -f 6 | sed -n "${Nomor}"p)
Quota=$(grep -E "###" "/etc/vless/.vless.db" | cut -d ' ' -f 5 | sed -n "${Nomor}"p)
expe=$(grep -E "###" "/etc/vless/.vless.db" | cut -d ' ' -f 3 | sed -n "${Nomor}"p)
tnggl=$(grep -E "###" "/etc/vless/.vless.db" | cut -d ' ' -f 7 | sed -n "${Nomor}"p)

# // Link Account Vless
vlesslink3="vless://${uuid}@${domain}:443?mode=gun&security=tls&encryption=none&type=grpc&serviceName=vless-grpc&sni=${domain}#${user}"

vlesslink1="vless://${uuid}@${domain}:80?path=/vless&encryption=none&host=${domain}&type=ws#${user}"

vlesslink2="vless://${uuid}@${domain}:443?path=/vless&security=tls&encryption=none&host=${domain}&type=ws&sni=${domain}#${user}"

loadingsc
sleep 1
clear
garis
echo -e " ${ungu}              VLESS ACCOUNT              ${NC}"
garis
echo -e " Username     : ${user}"
echo -e " Domain       : ${domain}"
echo -e " User Quota   : ${Quota} GB"
echo -e " User IP      : ${iplimit} Device"
echo -e " User ID      : ${uuid}"
echo -e " Encryption   : none"
echo -e " Path Dynamic : https://bug.com/vless"
echo -e " Path         : /vless"
echo -e " ServiceName  : vless-grpc"
echo -e " Port WS TLS  : 443, 8443, 2053"
echo -e " Port WS NTLS : 80, 8080, 8880, 2052, 2082"
garis
echo -e " Link WS TLS  : ${vlesslink1}"
garis
echo -e " Link WS NTLS : ${vlesslink2}"
garis
echo -e " Link GRPC    : ${vlesslink3}"
garis
echo -e " Format For Clash: https://${domain}:81/vless-$user.txt"
garis
echo -e " Created On       : $tnggl"
echo -e " Expired On       : $expe"
garis
Credit_Sc
