#!/bin/bash
# //            🇵🇸 FREE PALESTINE 🇵🇸
# //                  🇮🇱 IS 🐷
# // ——————————————————————————————
# // Config SSH Account by XDXL STORE 🇮🇩
# // My Telegram: t.me/xdxl_store
# // My Channel: t.me/xdx_vpn
# // Telegram Group: t.me/GrupConfigId
# // Config User TROJAN Account
# // ——————————————————————————————

Green="\e[92;1m"
RED="\033[31m"
PUB=$(cat /etc/slowdns/server.pub)
NS=$(cat /etc/xray/dns)
domain=$(cat /etc/xray/domain)
IP=$(curl -sS ipv4.icanhazip.com)
CITY=$(cat /etc/xray/city)
NC='\033[0m'
y="\033[1;93m"
g="\033[1;92m"
ungu='\033[0;35m'

function loadingsc() {
echo -e ""
echo -ne "Please wait... "
load
}

function garis() {
echo -e "${y} ────────────────────────────────────────────${NC}"
}

function Credit_Sc() {
sleep 1
echo -e ""
garis 
echo -e "${ungu}      Terimakasih sudah menggunakan-"
echo -e "        Script premium by Xdxl vpn"
garis
echo -e ""
exit 0
}

clear
NUMBER_OF_CLIENTS=$(grep -c -E "#tr#" "/etc/xray/config.json")
if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
echo -e "${y}───────────────────────────${NC}"
echo -e "\e[1;97;101m   CONFIG TROJAN ACCOUNT   ${NC}"
echo -e "${y}───────────────────────────${NC}"
echo ""
echo "You have no existing clients!"
clear
exit 1
fi

echo -e "${y}───────────────────────────${NC}"
echo -e "\e[1;97;101m   CONFIG TROJAN ACCOUNT   ${NC}"
echo -e "${y}───────────────────────────${NC}"
echo "     No User  Expired"
grep -E "#tr# " "/etc/xray/config.json" | cut -d ' ' -f 2-3 | nl -s ') '
until [[ ${Nomor} -ge 1 && ${Nomor} -le ${NUMBER_OF_CLIENTS} ]]; do
if [[ ${Nomor} == '1' ]]; then
read -rp "Select one client [1]: " Nomor
else
read -rp "Select one client [1-${NUMBER_OF_CLIENTS}]: " Nomor
fi
done

user=$(grep -E "###" "/etc/trojan/.trojan.db" | cut -d ' ' -f 2 | sed -n "${Nomor}"p)
uuid=$(grep -E "###" "/etc/trojan/.trojan.db" | cut -d ' ' -f 4 | sed -n "${Nomor}"p)
iplimit=$(grep -E "###" "/etc/trojan/.trojan.db" | cut -d ' ' -f 6 | sed -n "${Nomor}"p)
Quota=$(grep -E "###" "/etc/trojan/.trojan.db" | cut -d ' ' -f 5 | sed -n "${Nomor}"p)
expe=$(grep -E "###" "/etc/trojan/.trojan.db" | cut -d ' ' -f 3 | sed -n "${Nomor}"p)
tnggl=$(grep -E "###" "/etc/trojan/.trojan.db" | cut -d ' ' -f 7 | sed -n "${Nomor}"p)

# Link Trojan Akun
trojanlink="trojan://${uuid}@${domain}:443?path=%2Ftrojan&security=tls&host=${domain}&type=ws&sni=${domain}#${user}"

trojanlink1="trojan://${uuid}@${domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan&sni=${domain}#${user}"

trojanlink2="trojan://${uuid}@${domain}:80?path=%2Ftrojan&security=none&host=${domain}&type=ws#${user}"

loadingsc
sleep 1
clear
garis
echo -e " ${ungu}             TROJAN ACCOUNT              ${NC}"
garis
echo -e " Username         : ${user}"
echo -e " Host/IP          : ${domain}"
echo -e " User Quota       : ${Quota} GB"
echo -e " User IP          : ${iplimit} Device"
echo -e " Port WS TLS      : 443, 8443, 2053"
echo -e " Port WS None TLS : 80, 8080, 8880, 2052, 2082"
echo -e " Uuid             : ${uuid}" 
echo -e " Path             : /trojan"
echo -e " Path Dynamic     : https://bug.com/trojan"
echo -e " ServiceName      : trojan" 
garis
echo -e " Link TLS          : ${trojanlink}" 
garis
echo -e " Link none TLS     : ${trojanlink2}" 
garis
echo -e " Link GRPC        : ${trojanlink1}" 
garis
echo -e " Format For Clash : https://${domain}:81/trojan-$user.txt" 
garis
echo -e " Created On       : $tnggl"
echo -e " Expired On       : $expe"
garis
Credit_Sc