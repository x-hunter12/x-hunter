#!/bin/bash
# //            🇵🇸 FREE PALESTINE 🇵🇸
# //                  🇮🇱 IS 🐷
# // ——————————————————————————————
# // Config SSH Account by XDXL STORE 🇮🇩
# // My Telegram: t.me/xdxl_store
# // My Channel: t.me/xdx_vpn
# // Telegram Group: t.me/GrupConfigId
# // Config User SSH Account
# // ——————————————————————————————

Green="\e[92;1m"
RED="\033[31m"
PUB=$(cat /etc/slowdns/server.pub)
NS=$(cat /etc/xray/dns)
domain=$(cat /etc/xray/domain)
IP=$(curl -sS ipv4.icanhazip.com)
CITY=$(cat /etc/xray/city)
NC='\033[0m'
y="\033[1;93m"
g="\033[1;92m"
ungu='\033[0;35m'

function loadingsc() {
echo -e ""
echo -ne "Please wait... "
load
}

function garis() {
echo -e "${y} ────────────────────────────────────────────${NC}"
}

function Credit_Sc() {
sleep 1
echo -e ""
garis 
echo -e "${ungu}      Terimakasih sudah menggunakan-"
echo -e "        Script premium by Xdxl vpn"
garis
echo -e ""
exit 0
}

clear
NUMBER_OF_CLIENTS=$(grep -c -E "#ssh# " "/etc/ssh/.ssh.db")
if [[ ${NUMBER_OF_CLIENTS} == '0' ]]; then
echo -e "${y}───────────────────────────\033[0m"
echo -e "\e[1;97;101m    CONFIG SSH ACCOUNT     \E[0m"
echo -e "${y}───────────────────────────\033[0m"
echo ""
echo "You have no existing clients!"
clear
exit 1
fi

echo -e "${y}───────────────────────────\033[0m"
echo -e "\e[1;97;101m    CONFIG SSH ACCOUNT     \E[0m"
echo -e "${y}───────────────────────────\033[0m"
echo "     No User  Expired"
grep -E "#ssh# " "/etc/ssh/.ssh.db" | cut -d ' ' -f 2-3 | nl -s ') '
until [[ ${Nomor} -ge 1 && ${Nomor} -le ${NUMBER_OF_CLIENTS} ]]; do
if [[ ${Nomor} == '1' ]]; then
read -rp "Select one client [1]: " Nomor
else
read -rp "Select one client [1-${NUMBER_OF_CLIENTS}]: " Nomor
fi
done

Login=$(grep -E "#ssh# " "/etc/ssh/.ssh.db" | cut -d ' ' -f 2 | sed -n "${Nomor}"p)
Pass=$(grep -E "#ssh# " "/etc/ssh/.ssh.db" | cut -d ' ' -f 5 | sed -n "${Nomor}"p)
iplimit=$(grep -E "#ssh# " "/etc/ssh/.ssh.db" | cut -d ' ' -f 4 | sed -n "${Nomor}"p)
expe=$(grep -E "#ssh# " "/etc/ssh/.ssh.db" | cut -d ' ' -f 3 | sed -n "${Nomor}"p)
tnggl=$(grep -E "#ssh# " "/etc/ssh/.ssh.db" | cut -d ' ' -f 6 | sed -n "${Nomor}"p)

loadingsc

clear
sleep 1
garis
echo -e " ${ungu}           SSH/OVPN ACCOUNT             ${NC}"
garis
echo -e " Username         : $Login"
echo -e " Password         : $Pass"
echo -e " Limit IP         : ${iplimit} User"
garis
echo -e " IP               : $IP"
echo -e " Host             : $domain"
echo -e " Port OpenSSH     : 22"
echo -e " Port SSH UDP     : 1-65535"
echo -e " Port Dropbear    : 143, 109"
echo -e " Port SSL/TLS     : 443"
echo -e " Port OVPN WS SSL : 443"
echo -e " Port OVPN SSL    : 443"
echo -e " Port OVPN TCP    : 443, 1194"
echo -e " Port OVPN UDP    : 2200"
echo -e " BadVPN           : 7100 - 7500"
echo -e " Port SSH WS      : 80, 8080, 8880, 2052, 2082"
echo -e " Port SSH WS SSL  : 443, 8443, 2053"
garis
echo -e " OVPN Download    : https://$domain:81/"
garis
echo -e " Save Link Account: https://$domain:81/ssh-$Login.txt"
garis
echo -e " Payload WS NTLS:"
echo -e " GET / HTTP/1.1[crlf]host: ${domain}[crlf]Upgrade: Websocket[crlf][crlf]"
garis
echo -e " Payload WS TLS:"
echo -e " GET http://bug.con/ HTTP/1.1[crlf]host: ${domain}[crlf]Upgrade: Websocket[crlf][crlf]"
garis
echo -e " Payload ENHANCED:"
echo -e " PATCH / HTTP/1.1[crlf]Host: ${domain}[crlf]Host: bug.com[crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf][crlf]" 
garis
echo -e " Created On       : $tnggl"
echo -e " Expired On       : $expe"
garis
Credit_Sc